package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;

@Service
public class StudentService {
	
	  @Autowired
	  StudentRepository repository;
	  @Autowired
	  AddressRepository Arepository;

	  
	  public List<Student> getAllStudents()
	    {
	        List<Student> employeeList = repository.findAll();
	         
	        if(employeeList.size() > 0) {
	            return employeeList;
	        } else {
	            return new ArrayList<Student>();
	        }
	    }
	  
	  public Student getStudentsId(int id) throws Exception 
	    {
	        Optional<Student> employee = repository.findById(id);
	         
	        if(employee.isPresent()) {
	            return employee.get();
	        } else {
	            throw new Exception("No employee record exist for given id");
	        }
	    }
	  
	    public Student createOrUpdateStudnet(Student student) throws Exception
	    {
	        Optional<Student> student1 = repository.findById(student.getId());
	         
	        if(student1.isPresent())
	        {
	           Student newStudent = student1.get();
	           newStudent.setId(student.getId());
	           newStudent.setFirstname(student.getFirstname());
	           newStudent.setLastname(student.getLastname());
	           newStudent.setEmail(student.getEmail());
	           newStudent.setUsername(student.getUsername());
	           newStudent.setPassword(student.getPassword());
	           newStudent.setConfirmpassword(student.getConfirmpassword());
	 
	           newStudent = repository.save(newStudent);
	             
	            return newStudent;
	        } else {
	        	
	        	
	        	
	        	Address address=new Address();
	        	address.setStudent(student);
	        	/*
	        	address.setStreet(student.getAddress().getStreet());
	        	address.setCity(student.getAddress().getCity());
	        	address.setState(student.getAddress().getState());
	           //Arepository.save(address);
	        
	        */
	        	/*
	        	JsonParser p = null;
	        	@SuppressWarnings("null")
				JsonNode studentNode = p.getCodec().readTree(p);

	  	      
	  	        address1.setStreet(studentNode.get("address").get("street").textValue());
	  	        address1.setCity(studentNode.get("address").get("city").textValue());
	  	        address1.setState(studentNode.get("address").get("state").textValue());
	  	        
	        	*/
	        	student.setAddress(address);
	        
	        	
	        	
	            student = repository.save(student);
	             
	            return student;
	        }
	    }
	    @Transactional
	    public void deleteStudentById(int id) throws Exception
	    {
	        Optional<Student> employee = repository.findById(id);
	         
	        if(employee.isPresent())
	        {
	            repository.deleteById(id);
	        } else {
	            throw new Exception("No employee record exist for given id");
	        }
	    }
}
