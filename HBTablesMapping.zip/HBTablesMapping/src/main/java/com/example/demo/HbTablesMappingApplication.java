package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HbTablesMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HbTablesMappingApplication.class, args);
	}

}
